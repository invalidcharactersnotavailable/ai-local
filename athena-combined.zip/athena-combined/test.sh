#!/usr/bin/env bash
# Test script for the Athena AI system

set -e

echo "=== Athena AI System Test ==="
echo "This script will test the complete Athena AI system."

# Check if Rust is installed
if ! command -v rustc &> /dev/null; then
    echo "Error: Rust is not installed. Please install Rust first."
    exit 1
fi

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Navigate to project root
cd "$(dirname "$0")"
PROJECT_ROOT="$(pwd)"

echo "Project root: $PROJECT_ROOT"

# Build Rust components
echo "=== Building Rust components ==="
cd "$PROJECT_ROOT/athena-core"
echo "Building athena-core..."
cargo build --release

cd "$PROJECT_ROOT/athena-api"
echo "Building athena-api..."
cargo build --release

# Build TypeScript components
echo "=== Building TypeScript components ==="
cd "$PROJECT_ROOT/athena-web"
echo "Installing dependencies..."
npm install
echo "Building TypeScript code..."
npm run build

# Create test directories
echo "=== Creating test directories ==="
mkdir -p "$PROJECT_ROOT/test/models"
mkdir -p "$PROJECT_ROOT/test/knowledge"

# Create test configuration
echo "=== Creating test configuration ==="
cat > "$PROJECT_ROOT/test/config.json" << EOF
{
  "memory_limit_mb": null,
  "cpu_threads": null,
  "auto_detect_resources": true,
  "model_name": "distilgpt2",
  "model_path": "$PROJECT_ROOT/test/models",
  "quantized": true,
  "max_sequence_length": 512,
  "streaming_inference": true,
  "knowledge_path": "$PROJECT_ROOT/test/knowledge",
  "max_knowledge_size_mb": null,
  "enable_search_index": true,
  "temperature": 0.7,
  "top_p": 0.9,
  "top_k": 40,
  "repetition_penalty": 1.1
}
EOF

# Start the Rust API server
echo "=== Starting Rust API server ==="
cd "$PROJECT_ROOT/athena-api"
RUST_LOG=info cargo run --release -- --config "$PROJECT_ROOT/test/config.json" --port 3000 &
RUST_API_PID=$!

# Wait for the API server to start
echo "Waiting for API server to start..."
sleep 5

# Start the TypeScript web server
echo "=== Starting TypeScript web server ==="
cd "$PROJECT_ROOT/athena-web"
PORT=8080 RUST_API_PORT=3000 RUST_API_HOST=localhost node dist/server.js &
TS_SERVER_PID=$!

# Wait for the web server to start
echo "Waiting for web server to start..."
sleep 5

# Run tests
echo "=== Running tests ==="

# Test health endpoint
echo "Testing health endpoint..."
curl -s http://localhost:8080/api/health | grep -q "ok" && echo "Health check passed!" || echo "Health check failed!"

# Test system resources endpoint
echo "Testing system resources endpoint..."
curl -s http://localhost:8080/api/system/resources | grep -q "total_memory_mb" && echo "System resources check passed!" || echo "System resources check failed!"

# Test chat endpoint
echo "Testing chat endpoint..."
curl -s -X POST -H "Content-Type: application/json" -d '{"messages":[{"role":"user","content":"Hello, Athena!"}]}' http://localhost:8080/api/chat | grep -q "assistant" && echo "Chat check passed!" || echo "Chat check failed!"

# Test knowledge endpoints
echo "Testing knowledge endpoints..."
# Add a knowledge item
KNOWLEDGE_ITEM=$(curl -s -X POST -H "Content-Type: application/json" -d '{"content":"This is a test knowledge item.","title":"Test Item","tags":["test"]}' http://localhost:8080/api/knowledge)
KNOWLEDGE_ID=$(echo $KNOWLEDGE_ITEM | grep -o '"id":"[^"]*"' | cut -d'"' -f4)

if [ -n "$KNOWLEDGE_ID" ]; then
    echo "Knowledge item created with ID: $KNOWLEDGE_ID"
    
    # Get the knowledge item
    curl -s http://localhost:8080/api/knowledge/$KNOWLEDGE_ID | grep -q "Test Item" && echo "Knowledge get check passed!" || echo "Knowledge get check failed!"
    
    # Search for the knowledge item
    curl -s -X POST -H "Content-Type: application/json" -d '{"query":"test"}' http://localhost:8080/api/knowledge/search | grep -q "Test Item" && echo "Knowledge search check passed!" || echo "Knowledge search check failed!"
    
    # Delete the knowledge item
    curl -s -X DELETE http://localhost:8080/api/knowledge/$KNOWLEDGE_ID | grep -q "success" && echo "Knowledge delete check passed!" || echo "Knowledge delete check failed!"
else
    echo "Failed to create knowledge item!"
fi

# Clean up
echo "=== Cleaning up ==="
kill $RUST_API_PID
kill $TS_SERVER_PID

echo "=== Test completed ==="
echo "All tests have been executed. Please check the results above."
