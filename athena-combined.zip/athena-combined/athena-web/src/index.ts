// Basic structure for the TypeScript web server
import express from 'express';
import cors from 'cors';
import { Server } from 'socket.io';
import http from 'http';
import axios from 'axios';
import dotenv from 'dotenv';
import winston from 'winston';

// Load environment variables
dotenv.config();

// Configure logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'athena-web.log' })
  ]
});

// Configuration
const PORT = process.env.PORT || 8080;
const RUST_API_URL = process.env.RUST_API_URL || 'http://localhost:3000';

// Create Express app
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API proxy endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/chat`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error proxying to Rust API:', error);
    res.status(500).json({ error: 'Failed to communicate with AI backend' });
  }
});

// WebSocket connection for streaming responses
io.on('connection', (socket) => {
  logger.info('Client connected');
  
  socket.on('chat-request', async (message) => {
    try {
      // Connect to Rust API WebSocket for streaming
      // This is a placeholder - actual implementation will depend on the Rust API
      const response = await axios.post(`${RUST_API_URL}/chat`, {
        message: message.text,
        stream: true
      });
      
      // For now, just send the complete response
      socket.emit('chat-response', response.data);
    } catch (error) {
      logger.error('Error processing chat request:', error);
      socket.emit('error', { message: 'Failed to process request' });
    }
  });
  
  socket.on('disconnect', () => {
    logger.info('Client disconnected');
  });
});

// Start server
server.listen(PORT, () => {
  logger.info(`Athena Web server running on port ${PORT}`);
  logger.info(`Connecting to Rust API at ${RUST_API_URL}`);
});

export default app;
