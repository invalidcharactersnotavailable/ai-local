// TypeScript client for interacting with the Athena AI system
import axios from 'axios';
import { io, Socket } from 'socket.io-client';

// Types
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatRequest {
  messages: ChatMessage[];
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
}

export interface ChatResponse {
  message: ChatMessage;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface KnowledgeItem {
  id: string;
  content: string;
  metadata: {
    title: string;
    source?: string;
    tags: string[];
    created_at: string;
    updated_at: string;
  };
}

export interface SearchResult {
  items: KnowledgeItem[];
  total: number;
}

export interface SystemResources {
  total_memory_mb: number;
  available_memory_mb: number;
  cpu_cores: number;
  cpu_usage_percent: number;
}

export interface ModelInfo {
  name: string;
  size_mb: number;
  is_quantized: boolean;
  vocab_size: number;
  max_sequence_length: number;
  memory_required_mb: number;
}

// Athena Client class
export class AthenaClient {
  private baseUrl: string;
  private socket: Socket | null = null;

  constructor(baseUrl: string = 'http://localhost:8080') {
    this.baseUrl = baseUrl;
  }

  // Connect to WebSocket for streaming responses
  public connect(): Socket {
    if (!this.socket) {
      this.socket = io(this.baseUrl);
      this.socket.on('connect', () => {
        console.log('Connected to Athena WebSocket');
      });
      this.socket.on('disconnect', () => {
        console.log('Disconnected from Athena WebSocket');
      });
      this.socket.on('error', (error) => {
        console.error('Athena WebSocket error:', error);
      });
    }
    return this.socket;
  }

  // Disconnect from WebSocket
  public disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  // Chat with Athena (non-streaming)
  public async chat(request: ChatRequest): Promise<ChatResponse> {
    const response = await axios.post(`${this.baseUrl}/api/chat`, request);
    return response.data;
  }

  // Chat with Athena (streaming)
  public async chatStream(request: ChatRequest, onMessage: (message: string) => void, onComplete: (response: ChatResponse) => void): void {
    // Ensure we're connected
    this.connect();

    // Set streaming flag
    request.stream = true;

    // Send request via WebSocket
    this.socket!.emit('chat-request', request);

    // Listen for responses
    this.socket!.on('chat-response-chunk', (chunk: { text: string }) => {
      onMessage(chunk.text);
    });

    this.socket!.on('chat-response-complete', (response: ChatResponse) => {
      onComplete(response);
      // Remove listeners to avoid duplicates on next request
      this.socket!.off('chat-response-chunk');
      this.socket!.off('chat-response-complete');
    });
  }

  // Get system resources
  public async getSystemResources(): Promise<SystemResources> {
    const response = await axios.get(`${this.baseUrl}/api/system/resources`);
    return response.data;
  }

  // Get available models
  public async getModels(): Promise<ModelInfo[]> {
    const response = await axios.get(`${this.baseUrl}/api/models`);
    return response.data;
  }

  // Download a model
  public async downloadModel(model: string, quantize: boolean = true): Promise<{ success: boolean; message: string }> {
    const response = await axios.post(`${this.baseUrl}/api/models/download`, { model, quantize });
    return response.data;
  }

  // Get knowledge items
  public async getKnowledgeItems(limit: number = 10, offset: number = 0): Promise<KnowledgeItem[]> {
    const response = await axios.get(`${this.baseUrl}/api/knowledge`, {
      params: { limit, offset }
    });
    return response.data;
  }

  // Get a specific knowledge item
  public async getKnowledgeItem(id: string): Promise<KnowledgeItem> {
    const response = await axios.get(`${this.baseUrl}/api/knowledge/${id}`);
    return response.data;
  }

  // Add a knowledge item
  public async addKnowledgeItem(content: string, title: string, source?: string, tags: string[] = []): Promise<KnowledgeItem> {
    const response = await axios.post(`${this.baseUrl}/api/knowledge`, {
      content,
      title,
      source,
      tags
    });
    return response.data;
  }

  // Delete a knowledge item
  public async deleteKnowledgeItem(id: string): Promise<{ success: boolean }> {
    const response = await axios.delete(`${this.baseUrl}/api/knowledge/${id}`);
    return response.data;
  }

  // Search knowledge
  public async searchKnowledge(query: string, limit: number = 10, offset: number = 0, tags?: string[]): Promise<SearchResult> {
    const response = await axios.post(`${this.baseUrl}/api/knowledge/search`, {
      query,
      limit,
      offset,
      tags
    });
    return response.data;
  }

  // Import knowledge from a file
  public async importKnowledge(filePath: string, titlePrefix?: string): Promise<KnowledgeItem[]> {
    const response = await axios.post(`${this.baseUrl}/api/knowledge/import`, {
      file_path: filePath,
      title_prefix: titlePrefix
    });
    return response.data;
  }

  // Export knowledge to a file
  public async exportKnowledge(filePath: string): Promise<{ count: number }> {
    const response = await axios.post(`${this.baseUrl}/api/knowledge/export`, {
      file_path: filePath
    });
    return response.data;
  }

  // Health check
  public async healthCheck(): Promise<{ status: string; timestamp: string; version: string }> {
    const response = await axios.get(`${this.baseUrl}/api/health`);
    return response.data;
  }
}

export default AthenaClient;
