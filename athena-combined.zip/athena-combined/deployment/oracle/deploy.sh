#!/bin/bash
# Oracle Cloud Infrastructure deployment script for Athena AI

# Variables
INSTANCE_NAME="athena-ai"
SHAPE="VM.Standard.A1.Flex"
CPU_COUNT="4"
MEMORY_GB="24"
BOOT_VOLUME_SIZE_GB="200"

# Create a cloud-init script
cat > cloud-init.yaml << EOF
#cloud-config
package_update: true
package_upgrade: true

packages:
  - curl
  - build-essential
  - pkg-config
  - libssl-dev
  - git

runcmd:
  # Install Rust
  - curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  - source $HOME/.cargo/env
  
  # Install Node.js
  - curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  - apt-get install -y nodejs
  
  # Clone the repository (replace with your repo)
  - git clone https://github.com/yourusername/athena-ai.git /home/ubuntu/athena-ai
  - cd /home/ubuntu/athena-ai
  
  # Run installation script
  - chmod +x install.sh
  - ./install.sh
  
  # Start the application
  - nohup ./start.sh > /home/ubuntu/athena.log 2>&1 &
EOF

echo "Oracle Cloud Infrastructure deployment files created."
echo "To deploy on Oracle Cloud:"
echo "1. Log in to your Oracle Cloud account"
echo "2. Navigate to Compute > Instances"
echo "3. Click 'Create Instance'"
echo "4. Configure your instance:"
echo "   - Name: $INSTANCE_NAME"
echo "   - Shape: $SHAPE"
echo "   - CPU: $CPU_COUNT"
echo "   - Memory: $MEMORY_GB GB"
echo "   - Boot Volume: $BOOT_VOLUME_SIZE_GB GB"
echo "5. In the 'Add SSH keys' section, upload your SSH public key"
echo "6. In the 'Show advanced options' section, upload the cloud-init.yaml file"
echo "7. Click 'Create' to create and start your instance"
echo "8. Once the instance is running, you can access Athena at http://[instance-ip]:8080"
