// Rust API server implementation for Athena
use axum::{
    routing::{get, post, delete},
    Router, Json, extract::{Path, Query, State},
    response::IntoResponse,
    http::StatusCode,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::RwLock;
use tower_http::cors::{CorsLayer, Any};
use std::net::SocketAddr;
use std::path::PathBuf;
use clap::Parser;
use athena_core::{
    AthenaConfig, Model, Tokenizer, InferenceEngine, KnowledgeStashSystem, KnowledgeAPI,
    huggingface::{HuggingFaceModel, ModelDownloader},
    optimization::{MemoryOptimizer, SystemResources},
    types::{KnowledgeItem, SearchQuery, SearchResult, InferenceParams, SystemResources as SystemResourcesType},
    error::Result,
};

// Application state
struct AppState {
    config: AthenaConfig,
    inference_engine: Arc<RwLock<InferenceEngine>>,
    knowledge_api: Arc<KnowledgeAPI>,
    memory_optimizer: Arc<RwLock<MemoryOptimizer>>,
    model_downloader: Arc<ModelDownloader>,
}

// Chat request
#[derive(Debug, Deserialize)]
struct ChatRequest {
    messages: Vec<ChatMessage>,
    temperature: Option<f32>,
    max_tokens: Option<usize>,
    stream: Option<bool>,
}

// Chat message
#[derive(Debug, Clone, Deserialize, Serialize)]
struct ChatMessage {
    role: String,
    content: String,
}

// Chat response
#[derive(Debug, Serialize)]
struct ChatResponse {
    message: ChatMessage,
    usage: Usage,
}

// Token usage
#[derive(Debug, Serialize)]
struct Usage {
    prompt_tokens: usize,
    completion_tokens: usize,
    total_tokens: usize,
}

// Knowledge query parameters
#[derive(Debug, Deserialize)]
struct KnowledgeQuery {
    limit: Option<usize>,
    offset: Option<usize>,
}

// Knowledge search request
#[derive(Debug, Deserialize)]
struct KnowledgeSearchRequest {
    query: String,
    limit: Option<usize>,
    offset: Option<usize>,
    tags: Option<Vec<String>>,
}

// Knowledge import request
#[derive(Debug, Deserialize)]
struct KnowledgeImportRequest {
    file_path: String,
    title_prefix: Option<String>,
}

// Knowledge export request
#[derive(Debug, Deserialize)]
struct KnowledgeExportRequest {
    file_path: String,
}

// Knowledge add request
#[derive(Debug, Deserialize)]
struct KnowledgeAddRequest {
    content: String,
    title: String,
    source: Option<String>,
    tags: Option<Vec<String>>,
}

// Model download request
#[derive(Debug, Deserialize)]
struct ModelDownloadRequest {
    model: String,
    quantize: Option<bool>,
}

// Success response
#[derive(Debug, Serialize)]
struct SuccessResponse {
    success: bool,
    message: String,
}

// Main function
#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    env_logger::init();
    
    // Parse command line arguments
    let args = Args::parse();
    
    // Load configuration
    let config = if let Some(config_path) = args.config {
        AthenaConfig::from_file(config_path.to_str().unwrap())?
    } else {
        AthenaConfig::default()
    };
    
    // Create memory optimizer
    let memory_optimizer = Arc::new(RwLock::new(MemoryOptimizer::new(config.clone())?));
    
    // Apply memory optimizations to config
    let optimized_config = {
        let optimizer = memory_optimizer.read().await;
        optimizer.apply_to_config(config.clone())
    };
    
    // Create model downloader
    let model_downloader = Arc::new(ModelDownloader::new(optimized_config.clone()));
    
    // Initialize model, tokenizer, and inference engine
    let model = Arc::new(RwLock::new(Model::new(optimized_config.clone()).await?));
    let tokenizer = Arc::new(Tokenizer::new(optimized_config.clone()).await?);
    let inference_engine = Arc::new(RwLock::new(InferenceEngine::new(
        model.clone(),
        tokenizer.clone(),
        optimized_config.clone(),
    )));
    
    // Initialize knowledge system
    let knowledge_system = Arc::new(KnowledgeStashSystem::new(optimized_config.clone()).await?);
    let knowledge_api = Arc::new(KnowledgeAPI::new(knowledge_system.clone()));
    
    // Create application state
    let app_state = Arc::new(AppState {
        config: optimized_config.clone(),
        inference_engine,
        knowledge_api,
        memory_optimizer,
        model_downloader,
    });
    
    // Create CORS layer
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);
    
    // Create router
    let app = Router::new()
        // Health check
        .route("/health", get(health_check))
        
        // Chat
        .route("/chat", post(chat))
        
        // System resources
        .route("/system/resources", get(system_resources))
        
        // Models
        .route("/models", get(list_models))
        .route("/models/download", post(download_model))
        
        // Knowledge
        .route("/knowledge", get(list_knowledge_items))
        .route("/knowledge", post(add_knowledge_item))
        .route("/knowledge/:id", get(get_knowledge_item))
        .route("/knowledge/:id", delete(delete_knowledge_item))
        .route("/knowledge/search", post(search_knowledge))
        .route("/knowledge/import", post(import_knowledge))
        .route("/knowledge/export", post(export_knowledge))
        
        // Add CORS and state
        .layer(cors)
        .with_state(app_state);
    
    // Determine address
    let addr = SocketAddr::from(([0, 0, 0, 0], args.port));
    
    // Start server
    println!("Athena API server listening on {}", addr);
    axum::Server::bind(&addr)
        .serve(app.into_make_service())
        .await
        .unwrap();
    
    Ok(())
}

// Health check handler
async fn health_check() -> impl IntoResponse {
    Json(serde_json::json!({
        "status": "ok",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "version": env!("CARGO_PKG_VERSION"),
    }))
}

// Chat handler
async fn chat(
    State(state): State<Arc<AppState>>,
    Json(request): Json<ChatRequest>,
) -> impl IntoResponse {
    // Convert messages to a prompt
    let prompt = request.messages.iter()
        .map(|msg| format!("{}: {}", msg.role, msg.content))
        .collect::<Vec<String>>()
        .join("\n");
    
    // Create inference parameters
    let params = InferenceParams {
        temperature: request.temperature.unwrap_or(0.7),
        max_tokens: request.max_tokens.unwrap_or(256),
        ..Default::default()
    };
    
    // Generate response
    let inference_engine = state.inference_engine.read().await;
    let result = inference_engine.generate(&prompt, Some(params)).await;
    
    match result {
        Ok(prediction) => {
            // Create response
            let response = ChatResponse {
                message: ChatMessage {
                    role: "assistant".to_string(),
                    content: prediction.text,
                },
                usage: Usage {
                    prompt_tokens: prediction.usage.prompt_tokens,
                    completion_tokens: prediction.usage.completion_tokens,
                    total_tokens: prediction.usage.total_tokens,
                },
            };
            
            (StatusCode::OK, Json(response))
        },
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to generate response: {}", e)
                }))
            )
        }
    }
}

// System resources handler
async fn system_resources() -> impl IntoResponse {
    match SystemResources::get_resources() {
        Ok(resources) => (StatusCode::OK, Json(resources)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to get system resources: {}", e)
                }))
            )
        }
    }
}

// List models handler
async fn list_models(
    State(state): State<Arc<AppState>>,
) -> impl IntoResponse {
    match state.model_downloader.get_downloaded_models() {
        Ok(models) => (StatusCode::OK, Json(models)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to list models: {}", e)
                }))
            )
        }
    }
}

// Download model handler
async fn download_model(
    State(state): State<Arc<AppState>>,
    Json(request): Json<ModelDownloadRequest>,
) -> impl IntoResponse {
    let quantize = request.quantize.unwrap_or(true);
    
    match state.model_downloader.download_model(&request.model, quantize).await {
        Ok(_) => {
            (
                StatusCode::OK,
                Json(SuccessResponse {
                    success: true,
                    message: format!("Successfully downloaded model: {}", request.model),
                })
            )
        },
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to download model: {}", e)
                }))
            )
        }
    }
}

// List knowledge items handler
async fn list_knowledge_items(
    State(state): State<Arc<AppState>>,
    Query(query): Query<KnowledgeQuery>,
) -> impl IntoResponse {
    let limit = query.limit.unwrap_or(10);
    let offset = query.offset.unwrap_or(0);
    
    match state.knowledge_api.get_all_items(limit, offset).await {
        Ok(items) => (StatusCode::OK, Json(items)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to list knowledge items: {}", e)
                }))
            )
        }
    }
}

// Get knowledge item handler
async fn get_knowledge_item(
    State(state): State<Arc<AppState>>,
    Path(id): Path<String>,
) -> impl IntoResponse {
    match state.knowledge_api.get_item(&id).await {
        Ok(Some(item)) => (StatusCode::OK, Json(item)),
        Ok(None) => {
            (
                StatusCode::NOT_FOUND,
                Json(serde_json::json!({
                    "error": format!("Knowledge item not found: {}", id)
                }))
            )
        },
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to get knowledge item: {}", e)
                }))
            )
        }
    }
}

// Add knowledge item handler
async fn add_knowledge_item(
    State(state): State<Arc<AppState>>,
    Json(request): Json<KnowledgeAddRequest>,
) -> impl IntoResponse {
    let tags = request.tags.unwrap_or_else(Vec::new);
    
    match state.knowledge_api.add_item(&request.content, &request.title, request.source.as_deref(), tags).await {
        Ok(item) => (StatusCode::CREATED, Json(item)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to add knowledge item: {}", e)
                }))
            )
        }
    }
}

// Delete knowledge item handler
async fn delete_knowledge_item(
    State(state): State<Arc<AppState>>,
    Path(id): Path<String>,
) -> impl IntoResponse {
    match state.knowledge_api.delete_item(&id).await {
        Ok(true) => {
            (
                StatusCode::OK,
                Json(SuccessResponse {
                    success: true,
                    message: format!("Successfully deleted knowledge item: {}", id),
                })
            )
        },
        Ok(false) => {
            (
                StatusCode::NOT_FOUND,
                Json(serde_json::json!({
                    "error": format!("Knowledge item not found: {}", id)
                }))
            )
        },
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to delete knowledge item: {}", e)
                }))
            )
        }
    }
}

// Search knowledge handler
async fn search_knowledge(
    State(state): State<Arc<AppState>>,
    Json(request): Json<KnowledgeSearchRequest>,
) -> impl IntoResponse {
    let limit = request.limit.unwrap_or(10);
    let offset = request.offset.unwrap_or(0);
    
    match state.knowledge_api.search(&request.query, limit, offset, request.tags).await {
        Ok(result) => (StatusCode::OK, Json(result)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to search knowledge: {}", e)
                }))
            )
        }
    }
}

// Import knowledge handler
async fn import_knowledge(
    State(state): State<Arc<AppState>>,
    Json(request): Json<KnowledgeImportRequest>,
) -> impl IntoResponse {
    match state.knowledge_api.import_from_file(&request.file_path, request.title_prefix.as_deref()).await {
        Ok(items) => (StatusCode::OK, Json(items)),
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to import knowledge: {}", e)
                }))
            )
        }
    }
}

// Export knowledge handler
async fn export_knowledge(
    State(state): State<Arc<AppState>>,
    Json(request): Json<KnowledgeExportRequest>,
) -> impl IntoResponse {
    match state.knowledge_api.export_to_file(&request.file_path).await {
        Ok(count) => {
            (
                StatusCode::OK,
                Json(serde_json::json!({
                    "success": true,
                    "count": count,
                    "message": format!("Successfully exported {} knowledge items", count)
                }))
            )
        },
        Err(e) => {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({
                    "error": format!("Failed to export knowledge: {}", e)
                }))
            )
        }
    }
}

// Command line arguments
#[derive(Parser)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Port to listen on
    #[arg(short, long, default_value_t = 3000)]
    port: u16,
    
    /// Path to configuration file
    #[arg(short, long)]
    config: Option<PathBuf>,
    
    /// Enable verbose logging
    #[arg(short, long)]
    verbose: bool,
}
