// Memory optimization manager for Athena Core
use crate::error::{AthenaError, Result};
use crate::config::AthenaConfig;
use crate::optimization::{MemoryTracker, SystemResources, Quantization, MemoryPool};
use crate::types::ModelInfo;
use std::sync::{Arc, Mutex};
use log::{info, warn, debug, error};

// Memory optimization levels
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptimizationLevel {
    None,       // No optimization
    Light,      // Light optimization for systems with plenty of memory
    Moderate,   // Moderate optimization for systems with adequate memory
    Aggressive, // Aggressive optimization for systems with limited memory
    Extreme,    // Extreme optimization for very memory-constrained systems
}

pub struct MemoryOptimizer {
    config: AthenaConfig,
    memory_pool: Arc<Mutex<MemoryPool>>,
    optimization_level: OptimizationLevel,
}

impl MemoryOptimizer {
    // Create a new memory optimizer with the given configuration
    pub fn new(config: AthenaConfig) -> Result<Self> {
        // Get available memory
        let available_memory = SystemResources::available_memory_mb()?;
        info!("Available memory: {} MB", available_memory);
        
        // Determine optimization level based on available memory
        let optimization_level = Self::determine_optimization_level(available_memory);
        info!("Selected optimization level: {:?}", optimization_level);
        
        // Create memory pool with appropriate size limit
        let pool_size_mb = match optimization_level {
            OptimizationLevel::None => None, // No limit
            OptimizationLevel::Light => Some(available_memory * 3 / 4), // 75% of available memory
            OptimizationLevel::Moderate => Some(available_memory * 2 / 3), // 66% of available memory
            OptimizationLevel::Aggressive => Some(available_memory / 2), // 50% of available memory
            OptimizationLevel::Extreme => Some(available_memory / 3), // 33% of available memory
        };
        
        let pool_size_bytes = pool_size_mb.map(|mb| mb * 1024 * 1024);
        let memory_pool = Arc::new(Mutex::new(MemoryPool::new(pool_size_bytes)));
        
        Ok(Self {
            config,
            memory_pool,
            optimization_level,
        })
    }
    
    // Determine optimization level based on available memory
    fn determine_optimization_level(available_memory_mb: usize) -> OptimizationLevel {
        match available_memory_mb {
            0..=2048 => OptimizationLevel::Extreme,      // <= 2GB: Extreme optimization
            2049..=4096 => OptimizationLevel::Aggressive, // 2-4GB: Aggressive optimization
            4097..=8192 => OptimizationLevel::Moderate,   // 4-8GB: Moderate optimization
            8193..=16384 => OptimizationLevel::Light,     // 8-16GB: Light optimization
            _ => OptimizationLevel::None,                 // > 16GB: No optimization
        }
    }
    
    // Get the current optimization level
    pub fn get_optimization_level(&self) -> OptimizationLevel {
        self.optimization_level
    }
    
    // Get the memory pool
    pub fn get_memory_pool(&self) -> Arc<Mutex<MemoryPool>> {
        self.memory_pool.clone()
    }
    
    // Recommend model based on available memory and optimization level
    pub fn recommend_model(&self) -> String {
        match self.optimization_level {
            OptimizationLevel::Extreme => "distilgpt2".to_string(),
            OptimizationLevel::Aggressive => "gpt2".to_string(),
            OptimizationLevel::Moderate => "gpt2-medium".to_string(),
            OptimizationLevel::Light => "gpt2-large".to_string(),
            OptimizationLevel::None => "gpt2-xl".to_string(),
        }
    }
    
    // Check if a model can fit in memory with current optimization level
    pub fn can_fit_model(&self, model_info: &ModelInfo) -> Result<bool> {
        let available_memory = SystemResources::available_memory_mb()?;
        
        // Apply safety factor based on optimization level
        let safety_factor = match self.optimization_level {
            OptimizationLevel::None => 1.1,      // 10% safety margin
            OptimizationLevel::Light => 1.2,     // 20% safety margin
            OptimizationLevel::Moderate => 1.3,  // 30% safety margin
            OptimizationLevel::Aggressive => 1.5, // 50% safety margin
            OptimizationLevel::Extreme => 2.0,   // 100% safety margin (very conservative)
        };
        
        let required_memory = (model_info.memory_required_mb as f32 * safety_factor) as usize;
        
        Ok(required_memory <= available_memory)
    }
    
    // Get optimization settings for the current level
    pub fn get_optimization_settings(&self) -> OptimizationSettings {
        match self.optimization_level {
            OptimizationLevel::None => OptimizationSettings {
                use_quantization: false,
                use_memory_mapping: true,
                max_batch_size: 16,
                cache_size_mb: 1024,
                use_disk_offloading: false,
                max_sequence_length: 2048,
                use_attention_slicing: false,
                use_gradient_checkpointing: false,
            },
            OptimizationLevel::Light => OptimizationSettings {
                use_quantization: false,
                use_memory_mapping: true,
                max_batch_size: 8,
                cache_size_mb: 512,
                use_disk_offloading: false,
                max_sequence_length: 1024,
                use_attention_slicing: false,
                use_gradient_checkpointing: false,
            },
            OptimizationLevel::Moderate => OptimizationSettings {
                use_quantization: true,
                use_memory_mapping: true,
                max_batch_size: 4,
                cache_size_mb: 256,
                use_disk_offloading: false,
                max_sequence_length: 768,
                use_attention_slicing: true,
                use_gradient_checkpointing: false,
            },
            OptimizationLevel::Aggressive => OptimizationSettings {
                use_quantization: true,
                use_memory_mapping: true,
                max_batch_size: 2,
                cache_size_mb: 128,
                use_disk_offloading: true,
                max_sequence_length: 512,
                use_attention_slicing: true,
                use_gradient_checkpointing: true,
            },
            OptimizationLevel::Extreme => OptimizationSettings {
                use_quantization: true,
                use_memory_mapping: true,
                max_batch_size: 1,
                cache_size_mb: 64,
                use_disk_offloading: true,
                max_sequence_length: 256,
                use_attention_slicing: true,
                use_gradient_checkpointing: true,
            },
        }
    }
    
    // Apply memory optimizations to configuration
    pub fn apply_to_config(&self, mut config: AthenaConfig) -> AthenaConfig {
        let settings = self.get_optimization_settings();
        
        // Apply optimization settings to config
        config.quantized = settings.use_quantization;
        config.max_sequence_length = settings.max_sequence_length;
        config.streaming_inference = true; // Always use streaming for memory efficiency
        
        // If auto-detect resources is enabled, recommend model based on available memory
        if config.auto_detect_resources {
            config.model_name = self.recommend_model();
        }
        
        config
    }
    
    // Monitor memory usage and adjust optimization level if needed
    pub async fn monitor_memory_usage(&mut self) -> Result<()> {
        // Get current memory usage
        let available_memory = SystemResources::available_memory_mb()?;
        let current_usage = MemoryTracker::current_usage() / (1024 * 1024); // Convert to MB
        
        debug!("Memory monitor: available={} MB, usage={} MB", available_memory, current_usage);
        
        // Check if we need to adjust optimization level
        let new_level = Self::determine_optimization_level(available_memory);
        
        if new_level != self.optimization_level {
            warn!("Adjusting optimization level from {:?} to {:?} due to memory pressure", 
                  self.optimization_level, new_level);
            
            self.optimization_level = new_level;
            
            // In a real implementation, we might trigger model reloading or other adjustments here
        }
        
        Ok(())
    }
}

// Optimization settings for different memory optimization levels
pub struct OptimizationSettings {
    pub use_quantization: bool,
    pub use_memory_mapping: bool,
    pub max_batch_size: usize,
    pub cache_size_mb: usize,
    pub use_disk_offloading: bool,
    pub max_sequence_length: usize,
    pub use_attention_slicing: bool,
    pub use_gradient_checkpointing: bool,
}
