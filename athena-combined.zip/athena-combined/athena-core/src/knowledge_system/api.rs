// API for the knowledge stash system
use crate::error::{AthenaError, Result};
use crate::types::{KnowledgeItem, SearchQuery, SearchResult};
use crate::knowledge_system::KnowledgeStashSystem;
use std::path::PathBuf;
use std::sync::Arc;
use log::{info, warn, debug, error};

pub struct KnowledgeAPI {
    system: Arc<KnowledgeStashSystem>,
}

impl KnowledgeAPI {
    // Create a new knowledge API with the given knowledge stash system
    pub fn new(system: Arc<KnowledgeStashSystem>) -> Self {
        Self { system }
    }
    
    // Add a knowledge item
    pub async fn add_item(&self, content: &str, title: &str, source: Option<&str>, tags: Vec<String>) -> Result<KnowledgeItem> {
        self.system.add_item(content, title, source, tags).await
    }
    
    // Get a knowledge item by ID
    pub async fn get_item(&self, id: &str) -> Result<Option<KnowledgeItem>> {
        self.system.get_item(id).await
    }
    
    // Delete a knowledge item by ID
    pub async fn delete_item(&self, id: &str) -> Result<bool> {
        self.system.delete_item(id).await
    }
    
    // Search for knowledge items
    pub async fn search(&self, query: &str, limit: usize, offset: usize, tags: Option<Vec<String>>) -> Result<SearchResult> {
        let search_query = SearchQuery {
            query: query.to_string(),
            limit,
            offset,
            tags,
        };
        
        self.system.search(&search_query).await
    }
    
    // Get all knowledge items with pagination
    pub async fn get_all_items(&self, limit: usize, offset: usize) -> Result<Vec<KnowledgeItem>> {
        self.system.get_all_items(limit, offset).await
    }
    
    // Get the total number of knowledge items
    pub async fn count(&self) -> Result<usize> {
        self.system.count().await
    }
    
    // Get the total size of the knowledge stash
    pub async fn size(&self) -> Result<u64> {
        self.system.size().await
    }
    
    // Import knowledge from a file
    pub async fn import_from_file(&self, file_path: &str, title_prefix: Option<&str>) -> Result<Vec<KnowledgeItem>> {
        let path = PathBuf::from(file_path);
        self.system.import_from_file(&path, title_prefix).await
    }
    
    // Export knowledge to a file
    pub async fn export_to_file(&self, file_path: &str) -> Result<usize> {
        let path = PathBuf::from(file_path);
        self.system.export_to_file(&path).await
    }
    
    // Find relevant knowledge for a query
    pub async fn find_relevant_knowledge(&self, query: &str, limit: usize) -> Result<Vec<String>> {
        self.system.find_relevant_knowledge(query, limit).await
    }
    
    // Enhance a prompt with relevant knowledge
    pub async fn enhance_prompt(&self, prompt: &str, max_knowledge_items: usize) -> Result<String> {
        // Find relevant knowledge
        let knowledge = self.system.find_relevant_knowledge(prompt, max_knowledge_items).await?;
        
        if knowledge.is_empty() {
            return Ok(prompt.to_string());
        }
        
        // Combine knowledge with prompt
        let mut enhanced_prompt = String::new();
        
        // Add knowledge context
        enhanced_prompt.push_str("### Relevant Knowledge:\n");
        for (i, item) in knowledge.iter().enumerate() {
            enhanced_prompt.push_str(&format!("--- Item {} ---\n{}\n\n", i + 1, item));
        }
        
        // Add separator
        enhanced_prompt.push_str("### User Query:\n");
        
        // Add original prompt
        enhanced_prompt.push_str(prompt);
        
        Ok(enhanced_prompt)
    }
}
