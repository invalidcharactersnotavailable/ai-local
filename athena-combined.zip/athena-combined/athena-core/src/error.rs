// Error handling for Athena Core
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AthenaError {
    #[error("Model error: {0}")]
    ModelError(String),

    #[error("Tokenization error: {0}")]
    TokenizationError(String),

    #[error("Inference error: {0}")]
    InferenceError(String),

    #[error("Knowledge stash error: {0}")]
    KnowledgeError(String),

    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("Serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),

    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Configuration error: {0}")]
    ConfigError(String),

    #[error("Resource not found: {0}")]
    NotFoundError(String),

    #[error("Memory limit exceeded: {0}")]
    MemoryLimitError(String),

    #[error("Unexpected error: {0}")]
    UnexpectedError(String),
}

pub type Result<T> = std::result::Result<T, AthenaError>;
