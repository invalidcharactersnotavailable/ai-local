// Tokenization implementation for Athena Core
use crate::error::{AthenaError, Result};
use crate::types::Token;
use crate::config::AthenaConfig;
use tokenizers::Tokenizer as HFTokenizer;
use tokenizers::models::bpe::BPE;
use std::path::Path;
use std::sync::Arc;
use log::{info, warn, debug, error};

pub struct Tokenizer {
    inner: Arc<HFTokenizer>,
    config: AthenaConfig,
}

impl Tokenizer {
    // Create a new tokenizer with the given configuration
    pub async fn new(config: AthenaConfig) -> Result<Self> {
        info!("Initializing tokenizer for model: {}", config.model_name);
        
        // Check if tokenizer exists, download if not
        let tokenizer_path = config.model_path.join(&config.model_name).join("tokenizer.json");
        
        let tokenizer = if tokenizer_path.exists() {
            // Load existing tokenizer
            HFTokenizer::from_file(tokenizer_path).map_err(|e| {
                AthenaError::TokenizationError(format!("Failed to load tokenizer: {}", e))
            })?
        } else {
            // For demo purposes, use a pre-trained tokenizer from HuggingFace
            // In a real implementation, we would download the tokenizer for the specific model
            HFTokenizer::from_pretrained("gpt2", None).map_err(|e| {
                AthenaError::TokenizationError(format!("Failed to load pretrained tokenizer: {}", e))
            })?
        };
        
        Ok(Self {
            inner: Arc::new(tokenizer),
            config,
        })
    }
    
    // Tokenize a string into tokens
    pub fn tokenize(&self, text: &str) -> Result<Vec<Token>> {
        let encoding = self.inner.encode(text, false).map_err(|e| {
            AthenaError::TokenizationError(format!("Failed to tokenize text: {}", e))
        })?;
        
        let ids = encoding.get_ids();
        let tokens = encoding.get_tokens();
        
        // Convert to our Token type
        let result = ids.iter().zip(tokens.iter()).enumerate().map(|(i, (&id, token))| {
            Token {
                id: id as usize,
                text: token.clone(),
                logprob: None, // Tokenizers don't provide logprobs
            }
        }).collect();
        
        Ok(result)
    }
    
    // Convert token IDs back to text
    pub fn decode(&self, token_ids: &[usize]) -> Result<String> {
        let ids: Vec<u32> = token_ids.iter().map(|&id| id as u32).collect();
        
        let text = self.inner.decode(&ids, false).map_err(|e| {
            AthenaError::TokenizationError(format!("Failed to decode tokens: {}", e))
        })?;
        
        Ok(text)
    }
    
    // Get the vocabulary size
    pub fn vocab_size(&self) -> usize {
        self.inner.get_vocab_size(false)
    }
    
    // Get the token ID for a special token
    pub fn token_to_id(&self, token: &str) -> Option<usize> {
        self.inner.token_to_id(token).map(|id| id as usize)
    }
    
    // Get the special token for a token ID
    pub fn id_to_token(&self, id: usize) -> Option<String> {
        self.inner.id_to_token(id as u32)
    }
}
