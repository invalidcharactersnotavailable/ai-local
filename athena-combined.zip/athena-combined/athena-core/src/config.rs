// Configuration for Athena Core
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AthenaConfig {
    // System resources configuration
    pub memory_limit_mb: Option<usize>,
    pub cpu_threads: Option<usize>,
    pub auto_detect_resources: bool,
    
    // Model configuration
    pub model_name: String,
    pub model_path: PathBuf,
    pub quantized: bool,
    pub max_sequence_length: usize,
    pub streaming_inference: bool,
    
    // Knowledge stash configuration
    pub knowledge_path: PathBuf,
    pub max_knowledge_size_mb: Option<usize>,
    pub enable_search_index: bool,
    
    // Inference configuration
    pub temperature: f32,
    pub top_p: f32,
    pub top_k: usize,
    pub repetition_penalty: f32,
}

impl Default for AthenaConfig {
    fn default() -> Self {
        Self {
            // Default to auto-detecting resources
            memory_limit_mb: None,
            cpu_threads: None,
            auto_detect_resources: true,
            
            // Default model configuration
            model_name: "gpt2".to_string(),  // Small model by default
            model_path: PathBuf::from("models"),
            quantized: true,  // Default to quantized for memory efficiency
            max_sequence_length: 1024,
            streaming_inference: true,
            
            // Default knowledge stash configuration
            knowledge_path: PathBuf::from("knowledge"),
            max_knowledge_size_mb: None,
            enable_search_index: true,
            
            // Default inference parameters
            temperature: 0.7,
            top_p: 0.9,
            top_k: 40,
            repetition_penalty: 1.1,
        }
    }
}

impl AthenaConfig {
    pub fn new() -> Self {
        Self::default()
    }
    
    pub fn with_model(mut self, model_name: &str) -> Self {
        self.model_name = model_name.to_string();
        self
    }
    
    pub fn with_memory_limit(mut self, memory_limit_mb: usize) -> Self {
        self.memory_limit_mb = Some(memory_limit_mb);
        self
    }
    
    pub fn with_cpu_threads(mut self, cpu_threads: usize) -> Self {
        self.cpu_threads = Some(cpu_threads);
        self
    }
    
    // Determine appropriate model based on available memory
    pub fn recommend_model_for_memory(available_memory_mb: usize) -> String {
        match available_memory_mb {
            0..=2048 => "distilgpt2".to_string(),     // Tiny model for very constrained systems
            2049..=4096 => "gpt2".to_string(),        // Small model
            4097..=8192 => "gpt2-medium".to_string(), // Medium model
            8193..=16384 => "gpt2-large".to_string(), // Large model
            _ => "gpt2-xl".to_string(),               // XL model for systems with plenty of RAM
        }
    }
    
    // Load configuration from file
    pub fn from_file(path: &str) -> Result<Self, std::io::Error> {
        let config_str = std::fs::read_to_string(path)?;
        let config = serde_json::from_str(&config_str)?;
        Ok(config)
    }
    
    // Save configuration to file
    pub fn save_to_file(&self, path: &str) -> Result<(), std::io::Error> {
        let config_str = serde_json::to_string_pretty(self)?;
        std::fs::write(path, config_str)?;
        Ok(())
    }
}
