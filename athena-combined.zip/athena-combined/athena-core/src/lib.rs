// Update lib.rs to include the knowledge_system module
pub mod model;
pub mod knowledge;
pub mod inference;
pub mod tokenization;
pub mod optimization;
pub mod types;
pub mod error;
pub mod config;
pub mod huggingface;
pub mod knowledge_system;

// Re-export commonly used items
pub use crate::model::Model;
pub use crate::knowledge::KnowledgeStash;
pub use crate::inference::InferenceEngine;
pub use crate::tokenization::Tokenizer;
pub use crate::error::AthenaError;
pub use crate::config::AthenaConfig;
pub use crate::huggingface::HuggingFaceModel;
pub use crate::knowledge_system::KnowledgeStashSystem;
