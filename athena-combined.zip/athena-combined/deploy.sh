#!/bin/bash
# Combined deployment script for Athena AI

echo "=== Athena AI Combined Deployment Script ==="
echo "This script helps you deploy Athena AI to your chosen cloud platform."
echo ""

# Function to display menu
show_menu() {
  echo "Please select a deployment platform:"
  echo "1) Fly.io (Free tier: 3x shared-cpu-1x 256MB VMs)"
  echo "2) Railway (Free tier: 500 hours/month, 5GB storage)"
  echo "3) Render (Free tier: 750 hours/month)"
  echo "4) Oracle Cloud (Free tier: 24GB RAM, 200GB storage)"
  echo "5) Exit"
  echo ""
  read -p "Enter your choice [1-5]: " choice
}

# Function to prepare Fly.io deployment
prepare_fly() {
  echo "Preparing for Fly.io deployment..."
  cp -f deployment/fly/Dockerfile ./
  cp -f deployment/fly/fly.toml ./
  echo "Files prepared for Fly.io deployment."
  echo ""
  echo "To deploy to Fly.io:"
  echo "1. Install the Fly CLI: curl -L https://fly.io/install.sh | sh"
  echo "2. Log in to Fly: fly auth login"
  echo "3. Create a new app: fly launch --name athena-ai"
  echo "4. Deploy the app: fly deploy"
  echo "5. Create a volume for persistent storage: fly volumes create athena_data --size 10"
  echo "6. Access your app at: https://athena-ai.fly.dev"
}

# Function to prepare Railway deployment
prepare_railway() {
  echo "Preparing for Railway deployment..."
  cp -f deployment/railway/Dockerfile ./
  cp -f deployment/railway/railway.json ./
  echo "Files prepared for Railway deployment."
  echo ""
  echo "To deploy to Railway:"
  echo "1. Create a Railway account at railway.app"
  echo "2. Install the Railway CLI: npm i -g @railway/cli"
  echo "3. Log in to Railway: railway login"
  echo "4. Initialize a new project: railway init"
  echo "5. Deploy the app: railway up"
  echo "6. Access your app at the URL provided by Railway"
}

# Function to prepare Render deployment
prepare_render() {
  echo "Preparing for Render deployment..."
  cp -f deployment/render/Dockerfile ./
  cp -f deployment/render/render.yaml ./
  echo "Files prepared for Render deployment."
  echo ""
  echo "To deploy to Render:"
  echo "1. Create a Render account at render.com"
  echo "2. Create a new Web Service"
  echo "3. Connect your GitHub repository"
  echo "4. Render will automatically detect the render.yaml file"
  echo "5. Click 'Create Web Service'"
  echo "6. Access your app at the URL provided by Render"
}

# Function to prepare Oracle Cloud deployment
prepare_oracle() {
  echo "Preparing for Oracle Cloud deployment..."
  cp -f deployment/oracle/deploy.sh ./
  chmod +x deploy.sh
  echo "Files prepared for Oracle Cloud deployment."
  echo ""
  echo "To deploy to Oracle Cloud:"
  echo "1. Run the deploy.sh script: ./deploy.sh"
  echo "2. Follow the instructions provided by the script"
  echo "3. Access your app at http://[instance-ip]:8080"
}

# Main script
show_menu

case $choice in
  1)
    prepare_fly
    ;;
  2)
    prepare_railway
    ;;
  3)
    prepare_render
    ;;
  4)
    prepare_oracle
    ;;
  5)
    echo "Exiting..."
    exit 0
    ;;
  *)
    echo "Invalid choice. Please try again."
    ;;
esac

echo ""
echo "Deployment files have been prepared. Follow the instructions above to complete the deployment."
echo "Thank you for using Athena AI!"
