#!/usr/bin/env bash
# Installation script for the Athena AI system

set -e

echo "=== Athena AI System Installation ==="
echo "This script will install the Athena AI system."

# Check if Rust is installed
if ! command -v rustc &> /dev/null; then
    echo "Rust is not installed. Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
else
    echo "Rust is already installed."
fi

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    echo "Node.js is already installed."
fi

# Navigate to project root
cd "$(dirname "$0")"
PROJECT_ROOT="$(pwd)"

echo "Project root: $PROJECT_ROOT"

# Create directories
echo "=== Creating directories ==="
mkdir -p "$PROJECT_ROOT/data/models"
mkdir -p "$PROJECT_ROOT/data/knowledge"

# Create configuration
echo "=== Creating configuration ==="
cat > "$PROJECT_ROOT/config.json" << EOF
{
  "memory_limit_mb": null,
  "cpu_threads": null,
  "auto_detect_resources": true,
  "model_name": "distilgpt2",
  "model_path": "$PROJECT_ROOT/data/models",
  "quantized": true,
  "max_sequence_length": 1024,
  "streaming_inference": true,
  "knowledge_path": "$PROJECT_ROOT/data/knowledge",
  "max_knowledge_size_mb": null,
  "enable_search_index": true,
  "temperature": 0.7,
  "top_p": 0.9,
  "top_k": 40,
  "repetition_penalty": 1.1
}
EOF

# Build Rust components
echo "=== Building Rust components ==="
cd "$PROJECT_ROOT/athena-core"
echo "Building athena-core..."
cargo build --release

cd "$PROJECT_ROOT/athena-api"
echo "Building athena-api..."
cargo build --release

# Build TypeScript components
echo "=== Building TypeScript components ==="
cd "$PROJECT_ROOT/athena-web"
echo "Installing dependencies..."
npm install
echo "Building TypeScript code..."
npm run build

# Create startup script
echo "=== Creating startup script ==="
cat > "$PROJECT_ROOT/start.sh" << EOF
#!/usr/bin/env bash
# Startup script for the Athena AI system

set -e

# Navigate to project root
cd "\$(dirname "\$0")"
PROJECT_ROOT="\$(pwd)"

# Start the Rust API server
echo "=== Starting Rust API server ==="
cd "\$PROJECT_ROOT/athena-api"
RUST_LOG=info cargo run --release -- --config "\$PROJECT_ROOT/config.json" --port 3000 &
RUST_API_PID=\$!

# Wait for the API server to start
echo "Waiting for API server to start..."
sleep 5

# Start the TypeScript web server
echo "=== Starting TypeScript web server ==="
cd "\$PROJECT_ROOT/athena-web"
PORT=8080 RUST_API_PORT=3000 RUST_API_HOST=localhost node dist/server.js &
TS_SERVER_PID=\$!

echo "=== Athena AI System Started ==="
echo "Web interface available at: http://localhost:8080"
echo "API available at: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop the servers."

# Handle shutdown
function cleanup {
  echo "Stopping servers..."
  kill \$RUST_API_PID
  kill \$TS_SERVER_PID
  echo "Servers stopped."
}

trap cleanup EXIT

# Wait for user to press Ctrl+C
wait
EOF

chmod +x "$PROJECT_ROOT/start.sh"

echo "=== Installation completed ==="
echo "You can start the Athena AI system by running: ./start.sh"
echo "Web interface will be available at: http://localhost:8080"
echo "API will be available at: http://localhost:3000"
