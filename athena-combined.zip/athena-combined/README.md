# Athena AI

Athena is a local AI assistant with a Rust backend and TypeScript web frontend. It's designed to run efficiently on systems with as little as 2GB RAM while also taking advantage of more resources (up to 16GB) when available.

## Features

- **Resource-Aware Design**: Automatically adapts to available system resources
- **Hugging Face Integration**: Uses pre-trained models from Hugging Face
- **Knowledge Stash**: Local storage system for AI reference information
- **Web Interface**: Easy-to-use web interface for interacting with the AI
- **Memory Optimization**: Quantization, memory mapping, and other techniques for efficient operation

## System Requirements

- **Minimum**: 2GB RAM, 2 CPU cores
- **Recommended**: 8GB+ RAM, 4+ CPU cores
- **Storage**: At least 1GB for the application, plus space for models (varies by model size)
- **Operating System**: Linux (tested on Ubuntu 22.04)
- **Dependencies**: Rust, Node.js

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/athena-ai.git
   cd athena-ai
   ```

2. Run the installation script:
   ```
   ./install.sh
   ```

   This script will:
   - Install Rust and Node.js if not already installed
   - Create necessary directories
   - Build the Rust components
   - Build the TypeScript components
   - Create a startup script

## Usage

1. Start the Athena AI system:
   ```
   ./start.sh
   ```

2. Open your web browser and navigate to:
   ```
   http://localhost:8080
   ```

3. You can now interact with Athena through the web interface.

## Architecture

Athena consists of several components:

1. **Rust Backend**:
   - `athena-core`: Core AI functionality (model, tokenizer, inference, knowledge stash)
   - `athena-api`: REST API server for the TypeScript frontend

2. **TypeScript Frontend**:
   - `athena-web`: Web server and user interface

## Configuration

The system configuration is stored in `config.json` in the project root. You can modify this file to change settings such as:

- Model name and path
- Memory limits
- Knowledge stash location
- Inference parameters

## Models

Athena uses models from Hugging Face. By default, it will use the smallest model that fits in your available memory. You can download models through the web interface or manually by placing them in the `data/models` directory.

Supported models:
- `distilgpt2` (~350MB): For very constrained systems (2GB RAM)
- `gpt2` (~550MB): For systems with 2-4GB RAM
- `gpt2-medium` (~1.2GB): For systems with 4-8GB RAM
- `gpt2-large` (~2.4GB): For systems with 8-16GB RAM
- `gpt2-xl` (~4.8GB): For systems with >16GB RAM

## Knowledge Stash

The knowledge stash allows you to store information that Athena can reference when answering questions. You can:

- Add knowledge items through the web interface
- Import knowledge from text files
- Export knowledge to text files
- Search the knowledge stash

## Development

### Project Structure

```
athena-ai/
├── athena-core/       # Core Rust library
├── athena-api/        # Rust API server
├── athena-web/        # TypeScript web server and UI
├── data/              # Data directory
│   ├── models/        # Model files
│   └── knowledge/     # Knowledge stash
├── config.json        # Configuration file
├── install.sh         # Installation script
├── start.sh           # Startup script
└── test.sh            # Test script
```

### Building from Source

To build the components manually:

1. Build the Rust components:
   ```
   cd athena-core
   cargo build --release
   cd ../athena-api
   cargo build --release
   ```

2. Build the TypeScript components:
   ```
   cd athena-web
   npm install
   npm run build
   ```

### Testing

Run the test script to verify that all components are working correctly:
```
./test.sh
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Rust-Bert](https://github.com/guillaume-be/rust-bert) for Rust bindings to Hugging Face models
- [Hugging Face](https://huggingface.co/) for pre-trained models
- [Axum](https://github.com/tokio-rs/axum) for the Rust web framework
- [Express](https://expressjs.com/) for the TypeScript web server
