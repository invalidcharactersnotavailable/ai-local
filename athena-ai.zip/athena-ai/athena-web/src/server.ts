// TypeScript web server implementation for Athena AI
import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import axios from 'axios';
import { spawn } from 'child_process';
import winston from 'winston';

// Configure logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ level, message, timestamp }) => {
      return `${timestamp} ${level}: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'athena-web.log' })
  ]
});

// Configuration
const PORT = process.env.PORT || 8080;
const RUST_API_PORT = process.env.RUST_API_PORT || 3000;
const RUST_API_HOST = process.env.RUST_API_HOST || 'localhost';
const RUST_API_URL = `http://${RUST_API_HOST}:${RUST_API_PORT}`;

// Create Express app
const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Start Rust API server if not already running
let rustApiProcess: any = null;

function startRustApiServer() {
  logger.info('Starting Rust API server...');
  
  // Check if Rust API is already running
  axios.get(`${RUST_API_URL}/health`)
    .then(() => {
      logger.info('Rust API server is already running');
    })
    .catch(() => {
      logger.info('Rust API server not detected, starting it...');
      
      // Start Rust API server
      const apiPath = path.join(__dirname, '../../athena-api/target/release/athena-api');
      
      // Check if the binary exists
      if (!fs.existsSync(apiPath)) {
        logger.error(`Rust API binary not found at ${apiPath}`);
        logger.info('Please build the Rust API server first with: cd athena-api && cargo build --release');
        return;
      }
      
      rustApiProcess = spawn(apiPath, ['serve', '--host', RUST_API_HOST, '--port', RUST_API_PORT.toString()]);
      
      rustApiProcess.stdout.on('data', (data: Buffer) => {
        logger.info(`Rust API: ${data.toString().trim()}`);
      });
      
      rustApiProcess.stderr.on('data', (data: Buffer) => {
        logger.error(`Rust API error: ${data.toString().trim()}`);
      });
      
      rustApiProcess.on('close', (code: number) => {
        logger.info(`Rust API server exited with code ${code}`);
        rustApiProcess = null;
      });
    });
}

// API routes
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '0.1.0'
  });
});

// System resources endpoint
app.get('/api/system/resources', async (req, res) => {
  try {
    const response = await axios.get(`${RUST_API_URL}/system/resources`);
    res.json(response.data);
  } catch (error) {
    logger.error('Error getting system resources:', error);
    res.status(500).json({ error: 'Failed to get system resources' });
  }
});

// Models endpoints
app.get('/api/models', async (req, res) => {
  try {
    const response = await axios.get(`${RUST_API_URL}/models`);
    res.json(response.data);
  } catch (error) {
    logger.error('Error getting models:', error);
    res.status(500).json({ error: 'Failed to get models' });
  }
});

app.post('/api/models/download', async (req, res) => {
  try {
    const { model, quantize } = req.body;
    const response = await axios.post(`${RUST_API_URL}/models/download`, { model, quantize });
    res.json(response.data);
  } catch (error) {
    logger.error('Error downloading model:', error);
    res.status(500).json({ error: 'Failed to download model' });
  }
});

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/chat`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error in chat request:', error);
    res.status(500).json({ error: 'Failed to process chat request' });
  }
});

// Knowledge endpoints
app.get('/api/knowledge', async (req, res) => {
  try {
    const { limit, offset } = req.query;
    const response = await axios.get(`${RUST_API_URL}/knowledge`, {
      params: { limit, offset }
    });
    res.json(response.data);
  } catch (error) {
    logger.error('Error getting knowledge items:', error);
    res.status(500).json({ error: 'Failed to get knowledge items' });
  }
});

app.get('/api/knowledge/:id', async (req, res) => {
  try {
    const response = await axios.get(`${RUST_API_URL}/knowledge/${req.params.id}`);
    res.json(response.data);
  } catch (error) {
    logger.error(`Error getting knowledge item ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to get knowledge item' });
  }
});

app.post('/api/knowledge', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/knowledge`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error adding knowledge item:', error);
    res.status(500).json({ error: 'Failed to add knowledge item' });
  }
});

app.delete('/api/knowledge/:id', async (req, res) => {
  try {
    const response = await axios.delete(`${RUST_API_URL}/knowledge/${req.params.id}`);
    res.json(response.data);
  } catch (error) {
    logger.error(`Error deleting knowledge item ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to delete knowledge item' });
  }
});

app.post('/api/knowledge/import', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/knowledge/import`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error importing knowledge:', error);
    res.status(500).json({ error: 'Failed to import knowledge' });
  }
});

app.post('/api/knowledge/export', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/knowledge/export`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error exporting knowledge:', error);
    res.status(500).json({ error: 'Failed to export knowledge' });
  }
});

app.post('/api/knowledge/search', async (req, res) => {
  try {
    const response = await axios.post(`${RUST_API_URL}/knowledge/search`, req.body);
    res.json(response.data);
  } catch (error) {
    logger.error('Error searching knowledge:', error);
    res.status(500).json({ error: 'Failed to search knowledge' });
  }
});

// WebSocket connection for streaming chat
io.on('connection', (socket) => {
  logger.info('Client connected');
  
  socket.on('chat-request', async (message) => {
    try {
      // For streaming responses, we need to connect to the Rust API's WebSocket
      // This is a simplified implementation - in a real app, we would use a WebSocket client
      const response = await axios.post(`${RUST_API_URL}/chat`, {
        ...message,
        stream: false // For now, we'll use non-streaming until we implement WebSocket client
      });
      
      socket.emit('chat-response', response.data);
    } catch (error) {
      logger.error('Error in WebSocket chat request:', error);
      socket.emit('error', { message: 'Failed to process chat request' });
    }
  });
  
  socket.on('disconnect', () => {
    logger.info('Client disconnected');
  });
});

// Start the server
server.listen(PORT, () => {
  logger.info(`Athena Web server running on port ${PORT}`);
  logger.info(`Connecting to Rust API at ${RUST_API_URL}`);
  
  // Start Rust API server if needed
  startRustApiServer();
});

// Handle shutdown
process.on('SIGINT', () => {
  logger.info('Shutting down...');
  
  // Kill Rust API server if we started it
  if (rustApiProcess) {
    logger.info('Stopping Rust API server');
    rustApiProcess.kill();
  }
  
  process.exit(0);
});

export default app;
