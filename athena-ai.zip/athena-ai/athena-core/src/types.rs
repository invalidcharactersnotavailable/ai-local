// Type definitions for Athena Core
use serde::{Deserialize, Serialize};

// Token representation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Token {
    pub id: usize,
    pub text: String,
    pub logprob: Option<f32>,
}

// Prediction result from the model
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Prediction {
    pub tokens: Vec<Token>,
    pub text: String,
    pub finish_reason: Option<String>,
    pub usage: TokenUsage,
}

// Token usage statistics
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TokenUsage {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub total_tokens: usize,
}

// Knowledge item stored in the knowledge stash
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeItem {
    pub id: String,
    pub content: String,
    pub metadata: KnowledgeMetadata,
}

// Metadata for knowledge items
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeMetadata {
    pub title: String,
    pub source: Option<String>,
    pub tags: Vec<String>,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub updated_at: chrono::DateTime<chrono::Utc>,
}

// Search query for the knowledge stash
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchQuery {
    pub query: String,
    pub limit: usize,
    pub offset: usize,
    pub tags: Option<Vec<String>>,
}

// Search result from the knowledge stash
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    pub items: Vec<KnowledgeItem>,
    pub total: usize,
}

// System resource information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemResources {
    pub total_memory_mb: usize,
    pub available_memory_mb: usize,
    pub cpu_cores: usize,
    pub cpu_usage_percent: f32,
}

// Model information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    pub name: String,
    pub size_mb: usize,
    pub is_quantized: bool,
    pub vocab_size: usize,
    pub max_sequence_length: usize,
    pub memory_required_mb: usize,
}

// Inference parameters
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceParams {
    pub temperature: f32,
    pub top_p: f32,
    pub top_k: usize,
    pub repetition_penalty: f32,
    pub max_tokens: usize,
    pub stop_sequences: Option<Vec<String>>,
}

impl Default for InferenceParams {
    fn default() -> Self {
        Self {
            temperature: 0.7,
            top_p: 0.9,
            top_k: 40,
            repetition_penalty: 1.1,
            max_tokens: 256,
            stop_sequences: None,
        }
    }
}
