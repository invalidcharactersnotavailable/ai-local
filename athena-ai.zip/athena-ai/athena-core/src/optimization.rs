// Memory optimization utilities for Athena Core
use crate::error::{AthenaError, Result};
use crate::config::AthenaConfig;
use half::f16;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use log::{info, warn, debug, error};
use std::mem;

// Static memory tracker to monitor memory usage across the application
static MEMORY_USAGE: AtomicUsize = AtomicUsize::new(0);

pub struct MemoryTracker;

impl MemoryTracker {
    // Register memory allocation
    pub fn allocate(bytes: usize) {
        let current = MEMORY_USAGE.fetch_add(bytes, Ordering::SeqCst);
        debug!("Memory allocated: {} bytes, total: {} bytes", bytes, current + bytes);
    }
    
    // Register memory deallocation
    pub fn deallocate(bytes: usize) {
        let current = MEMORY_USAGE.fetch_sub(bytes, Ordering::SeqCst);
        debug!("Memory deallocated: {} bytes, total: {} bytes", bytes, current - bytes);
    }
    
    // Get current memory usage
    pub fn current_usage() -> usize {
        MEMORY_USAGE.load(Ordering::SeqCst)
    }
    
    // Reset memory tracker
    pub fn reset() {
        MEMORY_USAGE.store(0, Ordering::SeqCst);
    }
}

// Memory-mapped tensor for efficient handling of large model weights
pub struct MappedTensor<T> {
    data: memmap2::Mmap,
    len: usize,
    _phantom: std::marker::PhantomData<T>,
}

impl<T: Copy + 'static> MappedTensor<T> {
    // Create a new memory-mapped tensor from a file
    pub fn new(path: &std::path::Path) -> Result<Self> {
        let file = std::fs::File::open(path)?;
        let metadata = file.metadata()?;
        let len = metadata.len() as usize / std::mem::size_of::<T>();
        
        let data = unsafe { memmap2::Mmap::map(&file)? };
        
        Ok(Self {
            data,
            len,
            _phantom: std::marker::PhantomData,
        })
    }
    
    // Get a slice of the tensor
    pub fn as_slice(&self) -> &[T] {
        unsafe {
            std::slice::from_raw_parts(
                self.data.as_ptr() as *const T,
                self.len,
            )
        }
    }
    
    // Get the length of the tensor
    pub fn len(&self) -> usize {
        self.len
    }
    
    // Check if the tensor is empty
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
}

// Quantization utilities
pub struct Quantization;

impl Quantization {
    // Quantize f32 values to f16 (half precision)
    pub fn f32_to_f16(values: &[f32]) -> Vec<f16> {
        values.iter().map(|&x| f16::from_f32(x)).collect()
    }
    
    // Dequantize f16 values to f32
    pub fn f16_to_f32(values: &[f16]) -> Vec<f32> {
        values.iter().map(|&x| f32::from(x)).collect()
    }
    
    // Quantize f32 values to i8 (8-bit integer)
    pub fn f32_to_i8(values: &[f32], scale: f32) -> Vec<i8> {
        values.iter().map(|&x| (x * scale).round() as i8).collect()
    }
    
    // Dequantize i8 values to f32
    pub fn i8_to_f32(values: &[i8], scale: f32) -> Vec<f32> {
        values.iter().map(|&x| x as f32 / scale).collect()
    }
    
    // Find optimal scale factor for i8 quantization
    pub fn find_optimal_scale(values: &[f32]) -> f32 {
        let max_abs = values.iter().fold(0.0f32, |max, &x| max.max(x.abs()));
        127.0 / max_abs
    }
}

// Memory pool for efficient allocation and reuse
pub struct MemoryPool {
    buffers: Vec<Vec<u8>>,
    available: Vec<usize>,
    total_bytes: usize,
    max_bytes: Option<usize>,
}

impl MemoryPool {
    // Create a new memory pool with optional maximum size
    pub fn new(max_bytes: Option<usize>) -> Self {
        Self {
            buffers: Vec::new(),
            available: Vec::new(),
            total_bytes: 0,
            max_bytes,
        }
    }
    
    // Allocate a buffer of the given size
    pub fn allocate(&mut self, size: usize) -> Result<&mut [u8]> {
        // Check if we would exceed the maximum size
        if let Some(max) = self.max_bytes {
            if self.total_bytes + size > max {
                return Err(AthenaError::MemoryLimitError(
                    format!("Memory limit exceeded: {} + {} > {}", self.total_bytes, size, max)
                ));
            }
        }
        
        // Try to reuse an available buffer
        if let Some(index) = self.find_available_buffer(size) {
            self.available.retain(|&i| i != index);
            return Ok(&mut self.buffers[index]);
        }
        
        // Allocate a new buffer
        let mut buffer = vec![0u8; size];
        let buffer_ref = &mut buffer[..];
        self.buffers.push(buffer);
        self.total_bytes += size;
        MemoryTracker::allocate(size);
        
        Ok(buffer_ref)
    }
    
    // Release a buffer back to the pool
    pub fn release(&mut self, index: usize) {
        if index < self.buffers.len() && !self.available.contains(&index) {
            self.available.push(index);
        }
    }
    
    // Find an available buffer of at least the given size
    fn find_available_buffer(&self, size: usize) -> Option<usize> {
        for &index in &self.available {
            if self.buffers[index].len() >= size {
                return Some(index);
            }
        }
        None
    }
    
    // Get the total bytes allocated
    pub fn total_bytes(&self) -> usize {
        self.total_bytes
    }
    
    // Get the number of available buffers
    pub fn available_buffers(&self) -> usize {
        self.available.len()
    }
}

impl Drop for MemoryPool {
    fn drop(&mut self) {
        MemoryTracker::deallocate(self.total_bytes);
    }
}

// System resource utilities
pub struct SystemResources;

impl SystemResources {
    // Get total system memory in MB
    pub fn total_memory_mb() -> Result<usize> {
        let mem_info = sys_info::mem_info()?;
        Ok((mem_info.total / 1024) as usize)
    }
    
    // Get available system memory in MB
    pub fn available_memory_mb() -> Result<usize> {
        let mem_info = sys_info::mem_info()?;
        Ok((mem_info.avail / 1024) as usize)
    }
    
    // Get number of CPU cores
    pub fn cpu_cores() -> Result<usize> {
        let cores = sys_info::cpu_num()?;
        Ok(cores as usize)
    }
    
    // Get CPU usage as a percentage
    pub fn cpu_usage_percent() -> Result<f32> {
        let cpu = sys_info::loadavg()?;
        // Convert load average to percentage (rough approximation)
        let cores = Self::cpu_cores()? as f32;
        let usage = (cpu.one * 100.0) / cores;
        Ok(usage)
    }
    
    // Get complete system resource information
    pub fn get_resources() -> Result<crate::types::SystemResources> {
        Ok(crate::types::SystemResources {
            total_memory_mb: Self::total_memory_mb()?,
            available_memory_mb: Self::available_memory_mb()?,
            cpu_cores: Self::cpu_cores()?,
            cpu_usage_percent: Self::cpu_usage_percent()?,
        })
    }
}
