// Model downloader for Hugging Face models
use crate::error::{AthenaError, Result};
use crate::config::AthenaConfig;
use crate::huggingface::HuggingFaceModel;
use std::path::{Path, PathBuf};
use std::fs;
use std::io::Write;
use log::{info, warn, debug, error};
use reqwest;
use indicatif::{ProgressBar, ProgressStyle};
use tokio::fs::File;
use tokio::io::AsyncWriteExt;

pub struct ModelDownloader {
    config: AthenaConfig,
}

impl ModelDownloader {
    // Create a new model downloader with the given configuration
    pub fn new(config: AthenaConfig) -> Self {
        Self { config }
    }
    
    // Download a model from Hugging Face
    pub async fn download_model(&self, model_name: &str, quantize: bool) -> Result<PathBuf> {
        info!("Downloading model: {} (quantize: {})", model_name, quantize);
        
        // Map model name to Hugging Face model ID
        let model_id = match model_name {
            "distilgpt2" => "distilgpt2",
            "gpt2" => "gpt2",
            "gpt2-medium" => "gpt2-medium",
            "gpt2-large" => "gpt2-large",
            "gpt2-xl" => "gpt2-xl",
            _ => {
                warn!("Unknown model name: {}, defaulting to gpt2", model_name);
                "gpt2"
            }
        };
        
        // Create model directory
        let model_dir = self.config.model_path.join(model_name);
        fs::create_dir_all(&model_dir)?;
        
        // Files to download
        let files = vec![
            "config.json",
            "vocab.json",
            "merges.txt",
            "rust_model.ot",
            "tokenizer.json",
        ];
        
        // Download each file
        for file in &files {
            let url = format!("https://huggingface.co/{}/resolve/main/{}", model_id, file);
            let target_path = model_dir.join(if *file == "rust_model.ot" { "model.ot" } else { file });
            
            if target_path.exists() {
                info!("File already exists: {:?}", target_path);
                continue;
            }
            
            info!("Downloading {} to {:?}", url, target_path);
            self.download_file(&url, &target_path).await?;
        }
        
        // Quantize model if requested
        if quantize {
            info!("Quantizing model: {}", model_name);
            self.quantize_model(&model_dir).await?;
        }
        
        info!("Model download completed: {}", model_name);
        Ok(model_dir)
    }
    
    // Download a file with progress bar
    async fn download_file(&self, url: &str, target_path: &Path) -> Result<()> {
        // Create client
        let client = reqwest::Client::new();
        
        // Send request
        let response = client.get(url)
            .send()
            .await
            .map_err(|e| AthenaError::IoError(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!("Failed to download file: {}", e)
            )))?;
        
        // Check if successful
        if !response.status().is_success() {
            return Err(AthenaError::IoError(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!("Failed to download file: HTTP {}", response.status())
            )));
        }
        
        // Get content length
        let total_size = response.content_length().unwrap_or(0);
        
        // Create progress bar
        let pb = ProgressBar::new(total_size);
        pb.set_style(ProgressStyle::default_bar()
            .template("{spinner:.green} [{elapsed_precise}] [{bar:40.cyan/blue}] {bytes}/{total_bytes} ({eta})")
            .unwrap()
            .progress_chars("#>-"));
        
        // Create file
        let mut file = File::create(target_path).await?;
        let mut downloaded: u64 = 0;
        let mut stream = response.bytes_stream();
        
        // Download file
        while let Some(item) = stream.next().await {
            let chunk = item.map_err(|e| AthenaError::IoError(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!("Error while downloading file: {}", e)
            )))?;
            file.write_all(&chunk).await?;
            let new = std::cmp::min(downloaded + (chunk.len() as u64), total_size);
            downloaded = new;
            pb.set_position(new);
        }
        
        pb.finish_with_message(format!("Downloaded {}", target_path.display()));
        Ok(())
    }
    
    // Quantize a model (placeholder for actual implementation)
    async fn quantize_model(&self, model_dir: &Path) -> Result<()> {
        // In a real implementation, this would use a library like tch to quantize the model
        // For now, we'll just create a marker file to indicate the model is quantized
        let marker_path = model_dir.join("quantized.marker");
        let mut file = fs::File::create(marker_path)?;
        file.write_all(b"This model has been quantized")?;
        
        info!("Model quantization completed (simulated): {:?}", model_dir);
        Ok(())
    }
    
    // Check if a model is already downloaded
    pub fn is_model_downloaded(&self, model_name: &str) -> bool {
        let model_dir = self.config.model_path.join(model_name);
        
        if !model_dir.exists() {
            return false;
        }
        
        // Check if all required files exist
        let required_files = vec![
            "config.json",
            "vocab.json",
            "merges.txt",
            "model.ot",
            "tokenizer.json",
        ];
        
        for file in &required_files {
            if !model_dir.join(file).exists() {
                return false;
            }
        }
        
        true
    }
    
    // Check if a model is quantized
    pub fn is_model_quantized(&self, model_name: &str) -> bool {
        let model_dir = self.config.model_path.join(model_name);
        model_dir.join("quantized.marker").exists()
    }
    
    // Get a list of downloaded models
    pub fn get_downloaded_models(&self) -> Result<Vec<String>> {
        let mut models = Vec::new();
        
        if !self.config.model_path.exists() {
            return Ok(models);
        }
        
        for entry in fs::read_dir(&self.config.model_path)? {
            let entry = entry?;
            let path = entry.path();
            
            if path.is_dir() {
                let model_name = path.file_name()
                    .and_then(|name| name.to_str())
                    .map(|name| name.to_string());
                
                if let Some(name) = model_name {
                    if self.is_model_downloaded(&name) {
                        models.push(name);
                    }
                }
            }
        }
        
        Ok(models)
    }
}
