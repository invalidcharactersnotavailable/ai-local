// Knowledge stash system implementation
use crate::error::{AthenaError, Result};
use crate::types::{KnowledgeItem, KnowledgeMetadata, SearchQuery, SearchResult};
use crate::config::AthenaConfig;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::RwLock;
use log::{info, warn, debug, error};

pub struct KnowledgeStashSystem {
    stash: Arc<RwLock<crate::knowledge::KnowledgeStash>>,
    config: AthenaConfig,
}

impl KnowledgeStashSystem {
    // Create a new knowledge stash system with the given configuration
    pub async fn new(config: AthenaConfig) -> Result<Self> {
        info!("Initializing knowledge stash system at {:?}", config.knowledge_path);
        
        // Create the knowledge stash
        let stash = crate::knowledge::KnowledgeStash::new(config.clone()).await?;
        
        Ok(Self {
            stash: Arc::new(RwLock::new(stash)),
            config,
        })
    }
    
    // Add an item to the knowledge stash
    pub async fn add_item(&self, content: &str, title: &str, source: Option<&str>, tags: Vec<String>) -> Result<KnowledgeItem> {
        let stash = self.stash.write().await;
        stash.add_item(content, title, source, tags).await
    }
    
    // Get an item from the knowledge stash
    pub async fn get_item(&self, id: &str) -> Result<Option<KnowledgeItem>> {
        let stash = self.stash.read().await;
        stash.get_item(id).await
    }
    
    // Delete an item from the knowledge stash
    pub async fn delete_item(&self, id: &str) -> Result<bool> {
        let stash = self.stash.write().await;
        stash.delete_item(id).await
    }
    
    // Search for items in the knowledge stash
    pub async fn search(&self, query: &SearchQuery) -> Result<SearchResult> {
        let stash = self.stash.read().await;
        stash.search(query).await
    }
    
    // Get all items in the knowledge stash
    pub async fn get_all_items(&self, limit: usize, offset: usize) -> Result<Vec<KnowledgeItem>> {
        let stash = self.stash.read().await;
        stash.get_all_items(limit, offset).await
    }
    
    // Get the total number of items in the knowledge stash
    pub async fn count(&self) -> Result<usize> {
        let stash = self.stash.read().await;
        stash.count().await
    }
    
    // Get the total size of the knowledge stash in bytes
    pub async fn size(&self) -> Result<u64> {
        let stash = self.stash.read().await;
        stash.size().await
    }
    
    // Import knowledge from a file
    pub async fn import_from_file(&self, file_path: &PathBuf, title_prefix: Option<&str>) -> Result<Vec<KnowledgeItem>> {
        info!("Importing knowledge from file: {:?}", file_path);
        
        // Check if file exists
        if !file_path.exists() {
            return Err(AthenaError::IoError(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("File not found: {:?}", file_path)
            )));
        }
        
        // Read file content
        let content = std::fs::read_to_string(file_path)?;
        
        // Split content into chunks (simple implementation - could be improved)
        let chunks = self.split_into_chunks(&content, 1000); // 1000 words per chunk
        
        // Generate title prefix
        let prefix = title_prefix.unwrap_or_else(|| {
            file_path.file_name()
                .and_then(|name| name.to_str())
                .unwrap_or("Imported")
        });
        
        // Add each chunk to the knowledge stash
        let mut items = Vec::new();
        let stash = self.stash.write().await;
        
        for (i, chunk) in chunks.iter().enumerate() {
            let title = format!("{} - Part {}", prefix, i + 1);
            let source = file_path.to_str().map(|s| s.to_string());
            let tags = vec!["imported".to_string()];
            
            let item = stash.add_item(
                chunk, 
                &title, 
                source.as_deref(), 
                tags
            ).await?;
            
            items.push(item);
        }
        
        info!("Imported {} chunks from file: {:?}", items.len(), file_path);
        Ok(items)
    }
    
    // Split text into chunks of approximately the specified number of words
    fn split_into_chunks(&self, text: &str, words_per_chunk: usize) -> Vec<String> {
        let words: Vec<&str> = text.split_whitespace().collect();
        let mut chunks = Vec::new();
        
        for chunk in words.chunks(words_per_chunk) {
            chunks.push(chunk.join(" "));
        }
        
        chunks
    }
    
    // Export knowledge to a file
    pub async fn export_to_file(&self, file_path: &PathBuf) -> Result<usize> {
        info!("Exporting knowledge to file: {:?}", file_path);
        
        // Get all items
        let stash = self.stash.read().await;
        let items = stash.get_all_items(usize::MAX, 0).await?;
        
        // Create file
        let mut file = std::fs::File::create(file_path)?;
        
        // Write items to file
        use std::io::Write;
        for item in &items {
            writeln!(file, "# {}", item.metadata.title)?;
            writeln!(file, "")?;
            writeln!(file, "{}", item.content)?;
            writeln!(file, "")?;
            writeln!(file, "Tags: {}", item.metadata.tags.join(", "))?;
            writeln!(file, "---")?;
            writeln!(file, "")?;
        }
        
        info!("Exported {} items to file: {:?}", items.len(), file_path);
        Ok(items.len())
    }
    
    // Find relevant knowledge for a given query
    pub async fn find_relevant_knowledge(&self, query: &str, limit: usize) -> Result<Vec<String>> {
        info!("Finding relevant knowledge for query: {}", query);
        
        // Create search query
        let search_query = SearchQuery {
            query: query.to_string(),
            limit,
            offset: 0,
            tags: None,
        };
        
        // Search for relevant items
        let stash = self.stash.read().await;
        let result = stash.search(&search_query).await?;
        
        // Extract content from items
        let contents: Vec<String> = result.items.iter()
            .map(|item| item.content.clone())
            .collect();
        
        Ok(contents)
    }
}
