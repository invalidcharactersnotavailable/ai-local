// Knowledge stash implementation for Athena Core
use crate::error::{AthenaError, Result};
use crate::types::{KnowledgeItem, KnowledgeMetadata, SearchQuery, SearchResult};
use crate::config::AthenaConfig;
use sled::Db;
use tantivy::{
    schema::{Schema, STORED, TEXT, INDEXED},
    Index, IndexWriter, IndexReader, ReloadPolicy,
    collector::TopDocs,
    query::QueryParser,
    doc,
};
use std::path::Path;
use std::sync::Arc;
use tokio::sync::RwLock;
use log::{info, warn, debug, error};
use chrono::Utc;
use serde_json;
use std::fs;

// Knowledge stash for storing and retrieving information
pub struct KnowledgeStash {
    db: Db,
    index: Option<Index>,
    index_writer: Option<Arc<RwLock<IndexWriter>>>,
    index_reader: Option<IndexReader>,
    schema: Option<Schema>,
    config: AthenaConfig,
}

impl KnowledgeStash {
    // Create a new knowledge stash with the given configuration
    pub async fn new(config: AthenaConfig) -> Result<Self> {
        info!("Initializing knowledge stash at {:?}", config.knowledge_path);
        
        // Create directory if it doesn't exist
        if !config.knowledge_path.exists() {
            fs::create_dir_all(&config.knowledge_path)?;
        }
        
        // Open the database
        let db_path = config.knowledge_path.join("knowledge.db");
        let db = sled::open(db_path)?;
        
        // Initialize search index if enabled
        let (index, index_writer, index_reader, schema) = if config.enable_search_index {
            Self::init_search_index(&config)?
        } else {
            (None, None, None, None)
        };
        
        Ok(Self {
            db,
            index,
            index_writer,
            index_reader,
            schema,
            config,
        })
    }
    
    // Initialize the search index
    fn init_search_index(config: &AthenaConfig) -> Result<(Option<Index>, Option<Arc<RwLock<IndexWriter>>>, Option<IndexReader>, Option<Schema>)> {
        let index_path = config.knowledge_path.join("search_index");
        
        // Create schema
        let mut schema_builder = Schema::builder();
        let id_field = schema_builder.add_text_field("id", TEXT | STORED);
        let title_field = schema_builder.add_text_field("title", TEXT | STORED);
        let content_field = schema_builder.add_text_field("content", TEXT | STORED);
        let tags_field = schema_builder.add_text_field("tags", TEXT | STORED);
        let schema = schema_builder.build();
        
        // Create or open index
        let index = if index_path.exists() {
            Index::open_in_dir(&index_path)?
        } else {
            fs::create_dir_all(&index_path)?;
            Index::create_in_dir(&index_path, schema.clone())?
        };
        
        // Create index writer
        let index_writer = index.writer(50_000_000)?; // 50MB buffer
        
        // Create index reader
        let index_reader = index.reader_builder()
            .reload_policy(ReloadPolicy::OnCommit)
            .try_into()?;
        
        Ok((Some(index), Some(Arc::new(RwLock::new(index_writer))), Some(index_reader), Some(schema)))
    }
    
    // Add an item to the knowledge stash
    pub async fn add_item(&self, content: &str, title: &str, source: Option<&str>, tags: Vec<String>) -> Result<KnowledgeItem> {
        // Generate a unique ID
        let id = format!("item_{}", Utc::now().timestamp_millis());
        
        // Create metadata
        let metadata = KnowledgeMetadata {
            title: title.to_string(),
            source: source.map(|s| s.to_string()),
            tags,
            created_at: Utc::now(),
            updated_at: Utc::now(),
        };
        
        // Create knowledge item
        let item = KnowledgeItem {
            id: id.clone(),
            content: content.to_string(),
            metadata,
        };
        
        // Serialize item
        let item_json = serde_json::to_string(&item)?;
        
        // Store in database
        self.db.insert(id.as_bytes(), item_json.as_bytes())?;
        
        // Index for search if enabled
        if let (Some(index), Some(index_writer), Some(schema)) = (&self.index, &self.index_writer, &self.schema) {
            let id_field = schema.get_field("id").unwrap();
            let title_field = schema.get_field("title").unwrap();
            let content_field = schema.get_field("content").unwrap();
            let tags_field = schema.get_field("tags").unwrap();
            
            let mut writer = index_writer.write().await;
            writer.add_document(doc!(
                id_field => item.id.clone(),
                title_field => item.metadata.title.clone(),
                content_field => content.to_string(),
                tags_field => item.metadata.tags.join(" ")
            ))?;
            writer.commit()?;
        }
        
        Ok(item)
    }
    
    // Get an item from the knowledge stash
    pub async fn get_item(&self, id: &str) -> Result<Option<KnowledgeItem>> {
        match self.db.get(id.as_bytes())? {
            Some(data) => {
                let item_json = String::from_utf8(data.to_vec())?;
                let item: KnowledgeItem = serde_json::from_str(&item_json)?;
                Ok(Some(item))
            }
            None => Ok(None),
        }
    }
    
    // Delete an item from the knowledge stash
    pub async fn delete_item(&self, id: &str) -> Result<bool> {
        // Remove from database
        let existed = self.db.remove(id.as_bytes())?.is_some();
        
        // Remove from search index if enabled
        if existed && let (Some(_), Some(index_writer), Some(schema)) = (&self.index, &self.index_writer, &self.schema) {
            let id_field = schema.get_field("id").unwrap();
            
            let mut writer = index_writer.write().await;
            writer.delete_term(tantivy::Term::from_field_text(id_field, id));
            writer.commit()?;
        }
        
        Ok(existed)
    }
    
    // Search for items in the knowledge stash
    pub async fn search(&self, query: &SearchQuery) -> Result<SearchResult> {
        if let (Some(index), Some(index_reader), Some(schema)) = (&self.index, &self.index_reader, &self.schema) {
            let content_field = schema.get_field("content").unwrap();
            let title_field = schema.get_field("title").unwrap();
            let tags_field = schema.get_field("tags").unwrap();
            
            // Create query parser
            let mut query_parser = QueryParser::for_index(
                index,
                vec![content_field, title_field, tags_field],
            );
            
            // Parse query
            let query_str = &query.query;
            let parsed_query = query_parser.parse_query(query_str)?;
            
            // Search
            let searcher = index_reader.searcher();
            let top_docs = searcher.search(
                &parsed_query,
                &TopDocs::with_limit(query.limit).and_offset(query.offset),
            )?;
            
            // Collect results
            let mut items = Vec::new();
            for (_score, doc_address) in top_docs {
                let retrieved_doc = searcher.doc(doc_address)?;
                let id_field = schema.get_field("id").unwrap();
                if let Some(id_value) = retrieved_doc.get_first(id_field) {
                    if let Some(id) = id_value.as_text() {
                        if let Some(item) = self.get_item(id).await? {
                            items.push(item);
                        }
                    }
                }
            }
            
            // Get total count
            let total = searcher.search(&parsed_query, &tantivy::collector::Count)?;
            
            Ok(SearchResult { items, total })
        } else {
            // If search index is not enabled, do a simple scan of the database
            let mut items = Vec::new();
            let mut total = 0;
            
            for result in self.db.iter() {
                if let Ok((_, value)) = result {
                    let item_json = String::from_utf8(value.to_vec())?;
                    let item: KnowledgeItem = serde_json::from_str(&item_json)?;
                    
                    // Simple text matching
                    if item.content.contains(&query.query) || 
                       item.metadata.title.contains(&query.query) ||
                       item.metadata.tags.iter().any(|tag| tag.contains(&query.query)) {
                        total += 1;
                        
                        // Only add if within offset/limit
                        if total > query.offset && items.len() < query.limit {
                            items.push(item);
                        }
                    }
                }
            }
            
            Ok(SearchResult { items, total })
        }
    }
    
    // Get all items in the knowledge stash
    pub async fn get_all_items(&self, limit: usize, offset: usize) -> Result<Vec<KnowledgeItem>> {
        let mut items = Vec::new();
        let mut count = 0;
        
        for result in self.db.iter() {
            if let Ok((_, value)) = result {
                count += 1;
                
                if count > offset && items.len() < limit {
                    let item_json = String::from_utf8(value.to_vec())?;
                    let item: KnowledgeItem = serde_json::from_str(&item_json)?;
                    items.push(item);
                }
            }
        }
        
        Ok(items)
    }
    
    // Get the total number of items in the knowledge stash
    pub async fn count(&self) -> Result<usize> {
        Ok(self.db.len())
    }
    
    // Get the total size of the knowledge stash in bytes
    pub async fn size(&self) -> Result<u64> {
        let db_size = self.db.size_on_disk()?;
        
        // Add index size if enabled
        let index_size = if let Some(index) = &self.index {
            // This is a placeholder - in a real implementation, we would measure the actual size
            0
        } else {
            0
        };
        
        Ok(db_size + index_size)
    }
}
