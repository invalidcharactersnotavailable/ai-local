// Inference engine implementation for Athena Core
use crate::error::{AthenaError, Result};
use crate::types::{Prediction, Token, TokenUsage, InferenceParams};
use crate::model::Model;
use crate::tokenization::Tokenizer;
use crate::config::AthenaConfig;
use std::sync::Arc;
use tokio::sync::{RwLock, mpsc};
use log::{info, warn, debug, error};

pub struct InferenceEngine {
    model: Arc<RwLock<Model>>,
    tokenizer: Arc<Tokenizer>,
    config: AthenaConfig,
}

impl InferenceEngine {
    // Create a new inference engine with the given model and tokenizer
    pub fn new(model: Arc<RwLock<Model>>, tokenizer: Arc<Tokenizer>, config: AthenaConfig) -> Self {
        Self {
            model,
            tokenizer,
            config,
        }
    }
    
    // Generate a prediction from the model
    pub async fn generate(&self, prompt: &str, params: Option<InferenceParams>) -> Result<Prediction> {
        let params = params.unwrap_or_default();
        
        // Tokenize the prompt
        let tokens = self.tokenizer.tokenize(prompt)?;
        let prompt_tokens = tokens.len();
        
        debug!("Generating prediction for prompt with {} tokens", prompt_tokens);
        
        // Get the model
        let model = self.model.read().await;
        
        // Generate prediction
        let prediction = model.predict(prompt, Some(params.clone())).await?;
        
        Ok(prediction)
    }
    
    // Generate a prediction with streaming output
    pub async fn generate_streaming(
        &self,
        prompt: &str,
        params: Option<InferenceParams>,
    ) -> Result<mpsc::Receiver<Result<Token>>> {
        let params = params.unwrap_or_default();
        
        // Create channel for streaming tokens
        let (tx, rx) = mpsc::channel(100);
        
        // Clone necessary data for the async task
        let model = self.model.clone();
        let prompt = prompt.to_string();
        
        // Spawn a task to generate tokens and send them through the channel
        tokio::spawn(async move {
            let model = model.read().await;
            
            match model.predict(&prompt, Some(params)).await {
                Ok(prediction) => {
                    // Send each token through the channel
                    for token in prediction.tokens {
                        if tx.send(Ok(token)).await.is_err() {
                            // Receiver was dropped, stop generating
                            break;
                        }
                    }
                }
                Err(e) => {
                    // Send the error through the channel
                    let _ = tx.send(Err(e)).await;
                }
            }
        });
        
        Ok(rx)
    }
    
    // Get the maximum sequence length supported by the model
    pub async fn max_sequence_length(&self) -> usize {
        let model = self.model.read().await;
        model.get_info().await.max_sequence_length
    }
    
    // Get the current memory usage of the model
    pub async fn memory_usage(&self) -> usize {
        let model = self.model.read().await;
        model.get_memory_usage().await
    }
}
